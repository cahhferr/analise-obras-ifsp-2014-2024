
# Análise de Obras Públicas no IFSP (2014–2024)

Este repositório contém os arquivos utilizados no estudo "Obras Públicas no IFSP (2014–2024): Uma Análise de Padrões por Clusterização de Dados Orçamentários".

## Objetivo
Identificar padrões de reforço, anulação e concentração contratual na execução orçamentária de obras públicas do IFSP, com base em dados do Portal da Transparência.

## Estrutura do Repositório
- **dados/**: contém os dados brutos (CSV) utilizados na análise.
- **notebooks/**: Jupyter notebooks com os passos da análise (pré-processamento, clusterização e visualizações).
- **scripts/**: scripts Python automatizados para clusterização.
- **output/graficos/**: gráficos gerados a partir das análises.

## Bibliotecas Utilizadas
- Python 3.10
- pandas
- matplotlib
- scikit-learn

## Execução
1. Instale as dependências listadas em `requirements.txt`
2. Execute os notebooks em sequência para reproduzir a análise.

## Licença
Este projeto está licenciado sob a Licença MIT.

## Créditos
Código desenvolvido por Camila de Carvalho Ferreira com apoio de modelo GPT-4 (OpenAI).
